.. _exceptions_module:

:mod:`pyramid.exceptions`
----------------------------

.. automodule:: pyramid.exceptions

  .. autoclass:: Forbidden

  .. autoclass:: NotFound

  .. autoclass:: ConfigurationError

  .. autoclass:: URLDecodeError
