MyProject README
